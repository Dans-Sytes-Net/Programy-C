#include <stdio.h>
#include <stdlib.h>

union super_int{
    int a;
    unsigned int a_u;
};


int main()
{
    printf("Hello world!\n");
    return 0;
}
