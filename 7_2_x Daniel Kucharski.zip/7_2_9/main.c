#include <stdio.h>
#include <stdlib.h>

struct lista{
    int a;
    struct lista *wsk;
};

int main()
{
    printf("Hello world!\n");
    return 0;
}
